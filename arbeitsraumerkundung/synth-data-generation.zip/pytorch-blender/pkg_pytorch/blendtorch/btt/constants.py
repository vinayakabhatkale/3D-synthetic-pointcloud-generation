'''Commonly used constants.'''

'''Default socket timeout 10 sec.'''
DEFAULT_TIMEOUTMS = 10000