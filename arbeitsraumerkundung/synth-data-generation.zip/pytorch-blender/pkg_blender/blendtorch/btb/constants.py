'''Commonly used constants.'''

'''Default socket timeout 5 sec.'''
DEFAULT_TIMEOUTMS = 5000
